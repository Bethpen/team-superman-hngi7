# Team-superman-hngi7 (Superman's repo for HNGi7)

# GUIDE LINES FOR WRITING YOUR SCRIPT:
## 1. Do NOT embed your script inside any form of html

## 2. Use simple logging functions. 
### For javaScript - console.log()
### for python - print(), 
### for php - echo.
 
## 3. Use this EXACT string format - "Hello World, this is [full name] with HNGi7 ID [ID] using [language] for stage 2 task.[Email]". Do not add colon ( : ), Dash (-) or any other character. 
## 4. Replace everything inside the square brackets including the square brackets, with the correct values. 

## 5. I REPEAT DO NOT ADD ANY OTHER CHARACTER TO IT, JUST REPLACE THE APPROPRIATE VALUES.

## 6. Save your file with a UNIQUE name. your username should be unique enough.

# RESULTS SO FAR

[Result page](https://ndubuisijr.github.io/superman-results) 

Your DESTINY is in your hands o...
