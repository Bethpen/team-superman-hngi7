var info = function(fullname, id, language, email) {
    return (`Hello World, this is ${fullname} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`)
    
}
var newInfo = info("Emmanuel Udoh", "HNG-02600", "Javascript", "eudoh940@gmail.com");
console.log(newInfo)