# -*- coding: utf-8 -*-
"""
Created on Wed Jun  3 03:12:07 2020

@author: nasio
"""

print ("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}"
       
       .format('Ohomina Osahon Francis', 'HNG-02635', 'Python' , 'contactosahonf@gmail.com'))