const result = function(name, id, email,language){
  return `Hello World, this is ${name} with HNGi7 ID ${id}
  using ${language} for stage 2 task. ${email}`

}

  console.log(result(" Christian Sunday", "HNG-03696", "Javascript", "chris4christ25@yahoo.com"))
