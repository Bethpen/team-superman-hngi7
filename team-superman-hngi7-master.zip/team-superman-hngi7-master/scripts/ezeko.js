//ezeko's details

console.log("Hello World, this is Ezekiel ADEJOBi with HNGi7 ID HNG-01657 using javaScript for stage 2 task.adejobiezekieladewole2017@gmail.com");