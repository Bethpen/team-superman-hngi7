let fullname = "Akinyemi Odebunmi";
let hngi7Id = "HNG-03885";
let language = "Javascript";
let myEmail = "akinyemiodebunmi@gmail.com";

    console.log(`Hello World, this is ${fullname} with HNGi7 ID ${hngi7Id} using ${language} for stage 2 task.${myEmail}`);