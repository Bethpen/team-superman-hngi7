//ES6 
//Initialization of Variable
let name = "Egbo Emmanuel";
let id = "HNG-04843";
let language = "JavaScript";
let email="emmanuelhills255@gmail.com";


function taskHng(name, id, language, email){

  console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`);
}
taskHng(name, id, language, email);

//I had to write the code from the beginning