fullname= "Eshomomoh Finbar Irosowe"
hng_id="HNG-01634"
language= "Python"
email="victorfinbarr@gmail.com"

print ("Hello World, this is", fullname,"with HNGi7 ID", hng_id, "using",language, "for stage 2 task.{}".format(email))



