// Declaring variables

var fullname, hngid, pl, email;
	fullname= "Lawal Lolade"; 
	hngid= "HNG-03243";
	pl= "Javascript";
	email= "loladelawal01@gmail.com";

// getting output using console

	console.log("Hello World, this is " + fullname + " with HNGi7 ID " + hngid + " using " + pl + " for stage 2 task."+email);
