
const introduce = () => {
  let details = `Hello World, this is Ademujimi Oluwaseyi with HNGi7 ID HNG-00685 using javascript for stage 2 task. oluwaseyifunmitan5@gmail.com`
  console.log(details)
}

introduce()
