def task_two(name, hng_id, stack, email_address):
    print("Hello World, this is {0} with HNGi7 ID {1} using {2} for stage 2 task.{3}" .format(name, hng_id, stack, email_address))


task_two("Promise Shittu", "HNG-06109", "Python", "promise.aeos@gmail.com")