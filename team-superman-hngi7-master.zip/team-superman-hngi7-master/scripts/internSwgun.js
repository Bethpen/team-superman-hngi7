const meetMe = (fullName, hngID, language, email) => {
    console.log(`Hello World, this is ${fullName} with HNGi7 ID ${hngID} using ${language} for stage 2 task.${email}`
    );
};

const fullName = 'BANJI Olusegun Kolawole';
const hngID = 'HNG-01595';
const language = 'JavaScript';
const email = 'segunbanji@gmail.com';

meetMe(fullName, hngID, language, email);
