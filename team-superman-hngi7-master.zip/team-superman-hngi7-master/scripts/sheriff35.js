function selfIntroduction(fullName, id, language, email) {
  console.log(
    `Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`
  );
}

selfIntroduction(
  "Sheriff Afolabi",
  "HNG-05208",
  "JavaScript",
  "sheriffopeyemi3@gmail.com"
);
