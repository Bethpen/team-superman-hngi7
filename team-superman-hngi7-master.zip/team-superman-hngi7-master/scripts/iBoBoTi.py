name = "Iroegbu Chukwuebuka"
id = "HNG-03100"
language = "Python"
email = "iroegbucalistus@gmail.com"
output = "Hello World, this is {0} with HNGi7 ID {1} using {2} for stage 2 task.{3}"
print(output.format(name, id, language, email))
