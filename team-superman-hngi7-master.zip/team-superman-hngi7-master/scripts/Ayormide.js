var HNGProfile = "Hello World, this is Okusanya Ayomide with HNGi7 ID HNG-04276 using Javascript for stage 2 task.okusanyaayomide1@gmail.com"
console.log(HNGProfile)