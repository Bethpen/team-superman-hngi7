const name = 'Agiamah Precious';
const hngId = 'HNG-04421';
const language = 'javascript';
const email = 'daphycisist@gmail.com'

console.log(`Hello world, this is ${name} with HNGi7 ID ${hngId} using ${language} for stage 2 task.${email}`);
