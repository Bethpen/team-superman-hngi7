myName = 'Abideen Muhammed'
myID = 'HNG-02878'
lang = 'python'
myEmail ='abideenmuhammed2018@gmail.com'
def myself(myName,myID,lang,myEmail):
    print(f"Hello World,this is {myName} with HNGi7 ID {myID} using {lang} for stage 2 task.{myEmail}")
    return
myself(myName,myID,lang,myEmail)
