<?php
$name = 'Nnamani Solomon'
$hngid = 'HNG-05483'
$language = 'PHP'
$email = 'nnamanisolomonblessing@gmail.com'
$output = "Hello World, this is $name with HNGi7 ID $hngid using $language for stage 2 task.$email"
echo $output
?>
