<?php 
$FullName = "Osemeke Onyekachukwu";
$HNGi7Id = "HNG-00924";
$Lang = "PHP";
$Email = "Osemeke89@gmail.com";


echo "Hello World, this is ".$FullName." with HNGi7 ID ".$HNGi7Id." using ".$Lang." for stage 2 task.".$Email;
?>
