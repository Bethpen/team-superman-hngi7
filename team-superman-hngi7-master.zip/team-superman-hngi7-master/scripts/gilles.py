print("Hello World, this is {0} with HNGi7 ID {1} using {2} for stage 2 task".format('Adjowotor Gabriel Gilles','HNG-03738','Python'))
