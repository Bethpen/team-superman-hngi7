data={'name':'Esther Wangari Waweru',
      'id':'HNG-01335','email':'estherwaweru86@gmail.com','language':'python'}
print('Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}'.
        format(data['name'],data['id'],data['language'],data['email']))
