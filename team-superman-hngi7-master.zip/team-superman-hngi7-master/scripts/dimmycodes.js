// stage 2 task

const introduceMyself = (fullName, id, language, email) => {
    console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`)
}

introduceMyself('Daniel Oladimeji', 'HNG-00236', 'JavaScript', 'danieloladimeji04@gmail.com')
