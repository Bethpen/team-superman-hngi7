print("Hello World, this is Francis Duru with HNGi7 ID HNG-290 using python for stage 2 task.phranqmaykus@gmail.com")
