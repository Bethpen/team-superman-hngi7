<?php
$myArray = array("Silas Aigbemekhe","HNG-03916","silas07official@gmail.com","PHP");

$message ="Hello World, this is " . $myArray[0] ." ". "with HNGi7 ID " . $myArray[1] ." "."using" ." ". $myArray[3] . " "."for stage 2 task." .$myArray[2];
echo $message;
?>
