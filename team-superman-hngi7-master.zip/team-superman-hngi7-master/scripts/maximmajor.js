const identification = (fullName, id, language, Email) => {
    const intro =`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${Email}`
    const detail=console.log(intro)
     return detail
    }
    identification('Amajor Ugochukwu Christian', 'HNG-01678', 'JavaScript','maximmajor4us@gmail.com')
