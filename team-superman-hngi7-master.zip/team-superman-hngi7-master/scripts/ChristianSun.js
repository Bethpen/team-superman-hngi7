const myInfo = function(){

  let fullName = "Christian Sunday";

  let hngId = "HNG-03696";

  let myEmail= "chris4christ25@yahoo.com";

  let languageUse = "JavaScript";

  let data = "Hello World, this is " + fullName + " with HNGi7 ID " + hngId + " using " + languageUse + " for stage 2 task."+ myEmail
  console.log(data)
}

myInfo()


