//this is task two
//function to run the code
var myName="Claire Munyole";
var identification="HNG-00045";
var scripting_language="Javascript";
var email="munyolec@gmail.com";
function task_two_hng_helloworld(name, idno, scripting_lang, mail) {
//output data
  console.log(
    "Hello World, this is " + name + " with HNGi7 ID " + idno + " using " + scripting_lang + " for stage 2 task."+ mail
  );
}
task_two_hng_helloworld(myName, identification, scripting_language,email);



