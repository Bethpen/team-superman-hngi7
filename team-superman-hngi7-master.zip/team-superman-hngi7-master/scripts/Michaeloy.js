const myProfile = (name, id, lang, email) => 
`"Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task.${email} "`;

console.log(myProfile("Michael John", "HNG-00424", "JavaScript", "johnmikeloy@gmail.com"));