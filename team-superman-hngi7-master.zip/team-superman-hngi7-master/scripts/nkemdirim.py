def main_details(name, hng_id, email, language):
	print("Hello World, this is " + name + " with HNGi7 ID " + hng_id + " using "+ language +" for stage 2 task.{}".format(email))
	

name = "Nkemdirim Collins" 
hng_id = "HNG-02026"
language = "Python" 
email = "collinsnkem8@gmail.com"	

if __name__ == "__main__":
	main_details(name, hng_id, email, language)