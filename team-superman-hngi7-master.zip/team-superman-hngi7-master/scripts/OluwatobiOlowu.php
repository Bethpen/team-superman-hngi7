<?php

$Name = "Oluwatobi Olowu";
$ID = "HNG-02668";
$Language = "PHP ";
$Email = "Tobytokpe@gmail.com";

$Task = "Hello World, this is " . $Name . " with HNGi7 ID " . $ID . " using " . $Language . "for stage 2 task." .$Email ;

echo $Task;

?>
