let fullName = 'Ude Agbai James';
let hngId = "HNG-01416";
let lang = "javascript";
let email = "agbai616@gmail.com";

const message = `Hello World, this is ${fullName} with HNGi7 ID ${hngId} using ${lang} for stage 2 task.${email}`;

console.log(message);