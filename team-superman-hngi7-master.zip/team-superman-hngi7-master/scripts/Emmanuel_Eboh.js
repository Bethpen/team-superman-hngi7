
    const name = "Emmanuel Eboh";
    const id = "HNG-01574";
const myemail = "ecolejnr007@gmail.com";
    const lang = "JavaScript";


    console.log(
        `Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task.${myemail}`
        );

