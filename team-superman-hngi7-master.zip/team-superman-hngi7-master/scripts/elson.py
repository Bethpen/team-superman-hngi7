# declare variables

name = "Elson Eguaosa"
hng_id = "HNG-00912"
prog_lang = "Python"
email = "eguaosaelson@hotmail.com"

# print output

print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}"
.format(name, hng_id, prog_lang, email))
