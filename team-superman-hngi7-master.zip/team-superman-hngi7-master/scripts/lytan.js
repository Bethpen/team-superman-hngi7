
function HNGi7(fullname, id, language, email){
	console.log(
		`Hello World, this is ${fullname} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`);
}
HNGi7("Olaitan dada", "HNG-00667", "javascript", "michaeldada09@gmail.com");