//Initiate Variables
var devName = "Chukwuebuka Onah";
var hngID = "HNG-01914";
var language = "JavaScript";
var mail = "revelationjay02@gmail.com";

//function to log data
function logData(name, id, lang, mail){
  //Log data
  console.log("Hello World, this is " + name + " with HNGi7 ID " + id + " using " + lang + " for stage 2 task."+ mail);
}

logData(devName, hngID, language, mail);