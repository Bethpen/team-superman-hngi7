<?php
$fullName = "Olabisi Aboge";
$internId = "HNG-03518";
$language = "PHP";
$email = "busolaboge@gmail.com";

echo "Hello World, this is $fullName with HNGi7 ID  $internId using $language for stage 2 task .$email";
?>