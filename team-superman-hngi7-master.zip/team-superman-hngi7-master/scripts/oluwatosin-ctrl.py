

task = {
    "Name":"Oluwatosin Mofikoya",
    "id": "HNG-02838",
    "Language" : "Python",
    "email":"mofikoyatosin@yahoo.com"
}
print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}".format(task["Name"], task["id"], task["Language"],task["email"]))