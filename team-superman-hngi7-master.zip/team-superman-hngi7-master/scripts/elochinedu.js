function intro() {
	const fullName = "Chinedu Ezeifeka";
	const hngid = "HNG-00360";
	const language = "JavaScript";
	const email = "elozonaezeifeka@gmail.com";
	
	console.log(`Hello World, this is ${fullName} with HNGi7 ID ${hngid} using ${language} for stage 2 task.${email}`);
}

intro();
