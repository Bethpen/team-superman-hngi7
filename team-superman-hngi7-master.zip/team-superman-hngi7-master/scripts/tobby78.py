def my_profile(first_name, last_name, language, hng_id, email):
    full_name = first_name + ' ' + last_name
    return print(f"Hello World, this is {full_name} with HNGi7 ID {hng_id} using {language} for stage 2 task.{email}")


my_profile('Kazeem', 'Omoloja', 'Python', 'HNG-03159','omolojakazeem@gmail.com')
