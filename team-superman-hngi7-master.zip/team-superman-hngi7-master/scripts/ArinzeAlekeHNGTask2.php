<?php

$name = "Arinzechukwu Aleke";
$id = "HNG-03073";
$language = "PHP";
$email = "emmanuelaleke@gmail.com";


$welcome='Hello World, this is '.$name .' with HNGi7 ID '. $id.' using '.$language . ' for stage 2 task.'.$email;

echo $welcome;

?>
