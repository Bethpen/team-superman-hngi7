let name = "Seun Ikubukuola";
let id = "HNG-04810";
let language = "NodeJs";
let email = "stchawenzy1405@gmail.com";

function myDetails() {
    let displayInfo = "Hello World, this is " + name + " with " + id + " using " + language + " for stage 2 task."+ email;
    console.log(displayInfo);
}
myDetails();