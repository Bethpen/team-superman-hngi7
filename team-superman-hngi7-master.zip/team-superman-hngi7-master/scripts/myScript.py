def introduction(fullname, my_id, language, email):
    print("Hello World, this is {0} with HNGi7 ID {1} using {2} for stage 2 task.{3}" .format(fullname, my_id, language, email))

introduction("Olagesin Samuel", "HNG-04817", "Python", "feyisamuell@gmail.com")
