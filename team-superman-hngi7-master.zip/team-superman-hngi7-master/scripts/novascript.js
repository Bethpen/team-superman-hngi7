console.log("Hello World, this is Emmanuel Ajibola with HNGi7 ID HNG-06562 using JavaScript for stage 2 task.aemmanuelblessing@gmail.com");
