def task(name, ID, language, email):
    print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}".format(name, ID, language, email))


task("Victor Famade", "HNG-01863", "Python", "famadevictor@gmail.com") 
