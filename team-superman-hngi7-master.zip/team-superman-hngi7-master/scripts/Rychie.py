 print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}".format("Richmond Ayitey","HND-00234","Python","richmondayitey12@gmail.com"))
