const shs = "Hello World, this is ONALEYE Temiloluwa with HNGi7 ID HNG-00967 using Javascript for stage 2 task.onaleyetemmy@outlook.com";

console.log(shs);
