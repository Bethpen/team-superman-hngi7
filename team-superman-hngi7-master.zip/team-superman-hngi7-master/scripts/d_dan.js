var name='Damilare Solanke';
var hngId='HNG-03896';
var language='Javascript';
var email='danieldamilare18@gmail.com';

function myScript(fullname,id,Language,email){
console.log(`Hello World, this is ${fullname} with HNGi7 ID ${id} using ${Language} for stage 2 task.${email}`);
}
myScript(name,hngId,language,email);
