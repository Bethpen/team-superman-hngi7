const name = 'Timo Heman';
const id = 'HNG-04851';
const language = 'javascript';
const email = 'timoheman16@gmail.com';

console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`);
