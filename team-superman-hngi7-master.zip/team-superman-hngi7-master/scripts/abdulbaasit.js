const hngDetails = (name, id, lang, email) => {
    console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task.${email}`);
}
 
hngDetails("Abdulbaasit Seriki", "HNG-05764" , "JavaScript", "baasisek01@gmail.com");