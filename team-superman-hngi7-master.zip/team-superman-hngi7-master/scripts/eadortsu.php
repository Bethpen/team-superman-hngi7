<?php

echo "Hello World, this is Eugene Adortsu with HNGi7 ID HNG-01429 using PHP for stage 2 task.mail@eadortsu.com";

