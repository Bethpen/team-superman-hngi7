function myScript (fullname,ID, language,email){
console.log(
`Hello World, this is ${fullname} with HNGi7 ID ${ID} using ${language} for stage 2 task.${email}`
);
}
myScript("Millicent Kiruri","HNG-03381","JavaScript","theemisskiruri@gmail.com");
