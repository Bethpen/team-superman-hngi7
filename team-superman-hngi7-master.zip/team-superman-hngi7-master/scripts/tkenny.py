name = 'Totoola Kehinde'
id = 'HNG-04512'
lang = 'Python'
email = 'totoolakenny@gmail.com'

message = 'Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}'.format(name, id, lang, email)

def userDetails():
    return message

print(userDetails())