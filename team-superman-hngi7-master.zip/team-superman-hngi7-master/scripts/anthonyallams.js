const outputTask = (fullName, hngId, programmingLanguage, emailAddress) =>
  console.log(
    `Hello World, this is ${fullName} with HNGi7 ID ${hngId} using ${programmingLanguage} for stage 2 task.${emailAddress}`
  );

outputTask(
  "Anthony Alaneme",
  "HNG-05805",
  "Javascript",
  "anthony.allams@gmail.com"
);
