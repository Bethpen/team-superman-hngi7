# TASK 2 DELIVERABLE FOR TEAM SUPERMAN.
# CREATED BY FAISAL PINDAR, PINDARU@YMAIL.COM
# WEDNESDAY, JUNE 3RD 2020. 14:10PM. EASTERN DAYLIGHT TIME.

def task2(fullname, ID, language, email):
  print("Hello World, this is " + fullname +  " with HNGi7 ID " +ID+ " using " +language+ " for stage 2 task."+email)

print(task2("Faisal Pindar", "HNG-00603", "Python", "pindaru@ymail.com"))