full_name = 'Abdul-hakam Abuda Oshiogwe'
hng_id = 'HNG-02429'
email_adr = 'princefame1@gmail.com'
lang = 'Python' 

print("Hello World, this is", full_name, "with HNGi7 ID", hng_id, "using", lang, "for stage 2 task.{}".format(email_adr))
