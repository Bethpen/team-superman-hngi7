print('Hello World, this is George Michael Dagogo with HNGi7 ID HNG-05094 using Python for stage 2 task.georgemichaeldagogogmaynard@gmail.com')
