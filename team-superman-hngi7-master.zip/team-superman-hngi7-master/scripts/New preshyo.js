const introduction = (fullName, id, language, Email) => {
const intro =`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${Email}`
console.log(intro)
  
}

introduction('Ohasonu Precious', 'HNG-00879', 'JavaScript', 'ohasonuprecious@yahoo.com')
