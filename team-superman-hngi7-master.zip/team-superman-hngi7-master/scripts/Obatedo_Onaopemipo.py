name = 'Obatedo Onaopemipo'
hng_id = 'HNG-04141'
language = 'Python'
email = 'opemeepo@yahoo.com'

print(f'Hello World, this is {name} with HNGi7 ID {hng_id} using {language} for stage 2 task.{email}')