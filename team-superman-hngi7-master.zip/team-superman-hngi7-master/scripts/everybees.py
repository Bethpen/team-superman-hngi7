"""
This is a script to print my details

"""
email = "everybees@gmail.com"


def stage_one_task(name, id, language):
    print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}".format(name, id, language, email))

stage_one_task("Jibola Bakare", "HNG-03475", "Python")
