function mydetails (){
    console.log("Hello World, this is " + name + " with HNGi7 ID " + id + " using " + language + " for stage 2 task." + email);
}
var name = "Nafisa Opemi Jimoh";
var id = "HNG-02454";
var language = "JavaScript";
var email = "jimohnafisa5@gmail.com"

mydetails();
