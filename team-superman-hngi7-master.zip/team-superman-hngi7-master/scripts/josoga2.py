print ("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}"
       
       .format('Adewale OGUNLEYE', 'HNG-00445', 'Python' , 'josoga2@gmail.com'))
