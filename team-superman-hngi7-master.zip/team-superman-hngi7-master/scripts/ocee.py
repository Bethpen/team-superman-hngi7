def script (name, hngid, language, email):
  print ('Hello world, this is ' +name+ ' with HNGI7 ID ' +hngid+ ' using ' +language+ ' for stage 2 task.'+email+'')

script ('Ochapa James', 'HNG-01510','python', 'ocjay24@gmail.com')