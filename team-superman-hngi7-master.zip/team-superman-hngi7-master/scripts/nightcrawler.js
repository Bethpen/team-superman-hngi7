let fullName = "Muyiwa Adebayo"
let id = "HNG-03038"
let language = "JavaScript"
let email = "muyiwa_david36@yahoo.com"

console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`)