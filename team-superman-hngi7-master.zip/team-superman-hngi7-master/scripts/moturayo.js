const displayMessage = () => {
    const motun = {
        fullName: "Idris Soliat Motunrayo",
        HNGid: "HND-00742",
        lang: "Javascript",
        email: "adejumobi.tunrayo@gmail.com"
    }

    console.log(`Hello World, this is ${motun.fullName} with HNGi7 ID ${motun.HNGid} using ${motun.lang} for stage 2 task.${motun.email}`)
}

displayMessage();