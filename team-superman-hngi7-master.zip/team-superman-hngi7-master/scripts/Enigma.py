print('Hello World, this is Emmanuel Oyovuohwo with HNGi7 ID HNG-01353 using python for stage 2 task.nuelking12@yahoo.com')
