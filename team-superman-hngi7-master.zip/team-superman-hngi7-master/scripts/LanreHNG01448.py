def larry(name, ID, language, email):
    print("Hello World, this is {} with HNGi7 ID {} using {} for Stage 2 task.{}".format(
        name, ID, language, email, ))


larry("Fatoki Lanre", "HNG-01448", "Python", "phattalph@gmail.com")
