<?php
//STOP commenting here

$hello = "Hello World, this is Tobi Folajin with HNGi7 ID HNG-00811 using PHP for stage 2 task.tobifolajin@gmail.com";
echo $hello;

?>
