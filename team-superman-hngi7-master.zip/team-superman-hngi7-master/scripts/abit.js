const name = "Sikiru Abidemi Tiamiyu";
const id = "HNG-00682";
const lang = "JavaScript";
const email = "tiamiyusikiruabidemi@gmail.com";

let sentence = `Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task.${email}`;

console.log(sentence);