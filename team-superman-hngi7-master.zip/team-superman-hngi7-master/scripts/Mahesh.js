const userName = "Maheswar reddy";
const id = "04099";
const language = "Javascript";
const emailId = "preddy@ec.iitr.ac.in"
console.log("Hello World, this is " + userName + " with HNGi7 ID HNG-" + id + " using " + language + " for stage 2 task." + emailId);
//Modified email for completion of task2