let fullName = "Tunde Adebanjo";
let id = "HNG-02925";
let language = "javascript";
let email = "tundeadebanjo246@gmail.com";


console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`)