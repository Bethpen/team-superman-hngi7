def display_details():

  print("Hello World, this is {name} with HNGi7 ID {hng_id} using {lang} for stage 2 task.{email}".format(name='Ernest Nyaaba', hng_id='HNG-05935', lang='Python', email='e.nyaab4@gmail.com'))

display_details()
