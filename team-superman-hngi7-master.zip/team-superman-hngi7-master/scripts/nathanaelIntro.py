name = "Nathanael Borketey-Kwaku"
iD = "HNG-01965"
language = "Python"
email = "nathanael@moonsquare.co"

print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}".format(name, iD, language, email))
