const myInfo = (name, ID, Language, Email) => {

 console.log (
    `Hello World, this is ${name} with HNGi7 ID ${ID} using ${Language} for stage 2 task.${Email}`
  );

}

myInfo("Osuji Chiaka Daniel", "HNG-03090", "Javascript", "chikajunior19@gmail.com");
