function greeting(myName, hngId, language, email) {

    console.log(`Hello World, This is ${myName} with HNGi7 ID ${hngId} using ${language} for the stage 2 task .${email}`);
}

greeting("Otor John", "HNG-03604", "Javascript", "johnogenyi4real@gmail.com");