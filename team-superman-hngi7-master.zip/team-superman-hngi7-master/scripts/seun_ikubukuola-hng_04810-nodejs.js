let full_name = "Seun Ikubukuola";
let identity = "HNG-04810";
let lang = "NodeJs";
let email = "stchawenzy1405@gmail.com";

console.log("Hello World, this is " + full_name + " with " + identity + " using " + lang + " for stage 2 task."+email );