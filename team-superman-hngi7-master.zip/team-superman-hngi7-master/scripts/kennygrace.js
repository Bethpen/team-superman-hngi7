function details (name,hngid,language,email ) {
console.log("Hello World, this is" + " " + name + " " + "with HNGi7 ID" + " " + hngid + " " + "using" + " " + language + " " + "for stage 2 task."+ email)
}
details ("Ige Kehinde", "HNG-00409", "JavaScript", "igekehinde90@gmail.com");
