function logHNG(name, id, language,email){
    console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`);
}

data = {
    "name":"Akpan Uwakmfon",
    "id":"HNG-06122",
    "language":"Javascript",
    "email":"astongemmy@gmail.com",
};

logHNG(data.name, data.id, data.language,data.email);
