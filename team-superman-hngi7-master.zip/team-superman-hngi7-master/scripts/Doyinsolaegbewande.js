//this is stage 2 task by Doyinsola 
//Declare variables
var fullName="Doyinsola Egbewande";
var idHNG="HNG-01670";
var usedLanguage="JavaScript";
var email="egbewandefolahanmi@gmail.com";
function doyinsola_helloworld(name, iD, lang, mail){
    //input data
    console.log("Hello World, this is " + name + " with HNGi7 ID " + iD + " using " + lang +" for stage 2 task."+ mail);  
}
doyinsola_helloworld(fullName, idHNG, usedLanguage, email);
