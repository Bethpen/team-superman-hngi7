def hello(name, ID, lang, email):
    print("Hello World, this is " + name + " with HNGi7 ID " + ID + " using " + lang + " for stage 2 task." + email)

hello("Kevin Edafe Oyovota", "HNG-03956", "Python", "edafe.oyovota@gmail.com")