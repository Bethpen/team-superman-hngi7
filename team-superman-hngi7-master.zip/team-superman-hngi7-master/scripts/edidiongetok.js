const email = 'etokedidionge@gmail.com'
const introduction = (fullName, hngID, language) => {
    console.log(`Hello World, this is ${fullName} with HNGi7 ID ${hngID} using ${language} for stage 2 task.${email}`);
}
introduction('Edidiong Etok', 'HNG-00806', 'Javascript');