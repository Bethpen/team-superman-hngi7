function myInfo() {

    let fullname = "Sodiq Farihan";
    let id = "HNG-03238";
    let language = "JavaScript";
    let email = "farhansodiq360@gmail.com";

    console.log(`Hello World, this is ${fullname} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`);
}

myInfo();

//function myDetails(fullname, ID, language){
//    console.log(`Hello World, this is ${fullname} with HNGi7 ID ${ID} using ${language} for Stage 2 task`);
//}

//myDetails("Sodiq Farihan", "HNG-03238", "JavaScript");
