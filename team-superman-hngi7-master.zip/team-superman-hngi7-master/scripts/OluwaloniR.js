function helloHng7(fullname, id, language, email) {
    console.log(
      `Hello World, this is ${fullname} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`
    );
  }
helloHng7("Sodeinde Olualoni Richard", "HNG-01180", "Javascript", "lonnyrichard77@gmail.com");