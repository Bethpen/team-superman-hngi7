#!/usr/bin/env python
# coding: utf-8

Full_name = "Godfred Nsabo"
HNGi7_ID = "HNG-05292"
Language = "Python"
Email = "godfred@aims.edu.gh"


print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}".format(Full_name, HNGi7_ID, Language, Email))



