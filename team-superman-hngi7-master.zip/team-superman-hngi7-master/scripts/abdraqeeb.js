const details = [
    "Ajao Abdur-Raqeeb",
    "HNG-01420",
    "Javascript",
    "Ajaorqb@gmail.com"
]

const text = (name, id, lang, email) => {
    console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task.${email}`);
};

text(details[0], details[1], details[2], details[3]);

