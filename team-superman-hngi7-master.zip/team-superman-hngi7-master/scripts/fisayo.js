//task2
console.log("Hello World, this is Fisayo Adesomoju with HNGi7 ID HNG-01794 using Javascript for stage 2 task.adesomojufisayo@gmail.com");