const hgn = (fullname, id, lang) => {
  let email =  'fmarvelsk@gmail.com'
  console.log(`Hello world, this is ${fullname} with HNGi7 ID ${id} using ${lang} for stage 2 task.${email}`)

}
hgn('Jide-Filani Marvellous','HNG-02447','Javascript')