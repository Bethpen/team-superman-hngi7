# - *- coding: utf- 8 - * -

import sys

introduction = "Hello World, this is %s with HNGi7 ID %s using %s for stage 2 task.%s"%("Daniel Tomiwa", "HNG-02027", "Python", "daniela.stomiwa@yahoo.com")

def intern_details():
	return introduction
	
	


if __name__ == "__main__":
	print(intern_details())

sys.stdout.flush()  