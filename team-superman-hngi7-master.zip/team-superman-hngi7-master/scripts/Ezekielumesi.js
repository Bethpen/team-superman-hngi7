let devName = "Ezekiel Umesi";
let hngID = "HNG-00356";
let language = "JavaScript";
let mail = "obusorezekiel@gmail.com";

// Function for the necessary data
function HNG_Data(name, id, lang, mail){
  console.log("Hello World, this is " + name + " with HNGi7 ID " + id + " using " + lang + " for stage 2 task."+ mail);
}

HNG_Data(devName, hngID, language, mail);