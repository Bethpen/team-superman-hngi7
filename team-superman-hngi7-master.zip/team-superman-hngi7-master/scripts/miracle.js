//declaring constant variables
const internDetails = {
    fullName: "Miracle Ogunleye",
    ID: "HNG-01741",
    language: "JavaScript",
    email: "ogunleyeolamide01@gmail.com"
}

fullName = internDetails.fullName;
id = internDetails.ID;
language = internDetails.language;
email = internDetails.email;

console.log("Hello World, this is " + fullName + " " + "with HNGi7 ID " + id + " using " + language + " for stage 2 task." + email);
