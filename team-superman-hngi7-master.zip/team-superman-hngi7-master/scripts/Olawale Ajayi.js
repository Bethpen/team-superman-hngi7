let container = [
    fullName = 'Olawale Ajayi',
    id = 'HNG-01549',
    email = 'ajayiolawale40@gmail.com',
    language = 'JavaScript'
];

console.log( 'Hello World, this is ' + container["0"] + ' with HNGi7 ID ' + container["1"] + ' using ' + container["3"] + ' for stage 2 task. ' + container["2"] );