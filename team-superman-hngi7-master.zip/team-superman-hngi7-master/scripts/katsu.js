const firstName = 'Victor';
const lastName = 'Orlunda';

const intershipId = 'HNG-04876';
const language = 'JavaScript';

const email = 'vicorlunda@gmail.com'

function info() {
	return `Hello World, this is ${firstName} ${lastName} with HNGi7 ID ${intershipId} using ${language} for stage 2 task. ${email}`;
}

console.log(info());