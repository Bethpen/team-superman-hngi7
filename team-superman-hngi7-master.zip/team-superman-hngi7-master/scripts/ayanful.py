def personal_info():
    name = "Ayanful Emmanuel Kwame"
    hng_id = "HNG-03582"
    language = "Python"
    email = "ekayanful@st.ug.edu.gh"
    print(f"Hello World, this is {name} with HNGi7 ID  {hng_id} using {language} for stage 2 task. {email}")

if __name__ == "__main__":
    personal_info()