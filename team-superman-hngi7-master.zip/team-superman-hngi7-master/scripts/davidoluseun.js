function greetings() {

    let name = `Oluwaseun David Anifowose`;
    let id = `HNG-01609`;
    let lang = `JavaScript`;
    let email = `a.davidoluseun@gmail.com`;

    let message = `Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task.${email}`;
    console.log(message);
}

greetings();
