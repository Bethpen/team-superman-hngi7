name = 'Chidi Arua'
hng_id = 'HNG-05000'
email = 'chidiarua99@gmail.com'
language = 'Python'

print(f"Hello World, this is {name} with HNGi7 ID {hng_id} using {language} for stage 2 task.{email}")