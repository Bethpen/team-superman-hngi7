var MyName = "Chesang Felister";
var IdNo = "HNG-01293";
var Email = "chesangfelister@gmail.com";
var Language = "JavaScript";

function displayMessage(MyName, IdNo, Language, Email) {
  console.log(
    "Hello World, this is " +
      MyName +
      IdNo +
      " i am using " +
      Language +
      " for stage 2 task. " +
      "My  email" +
      Email
  );
}

displayMessage(MyName, IdNo, Language, Email);
