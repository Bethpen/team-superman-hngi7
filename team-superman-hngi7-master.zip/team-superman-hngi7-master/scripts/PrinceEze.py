my_file = "Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}"
print(my_file.format('Prince Eze', 'HNG-03067', 'Python', 'pchidireeze@gmail.com'))
