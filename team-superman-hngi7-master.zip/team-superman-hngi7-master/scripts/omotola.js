const Mydetails = (fullName, id, language, email) => {
  console.log(
    `Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`
  );
};
Mydetails(
  'Omotola Ogundare',
  'HNG-04787',
  'Javascript',
  'tola.ogundare@yahoo.com'
);
