const name = "Osagie Erhabor";
const id = "HNG-02534";
const lang = "Javascript";
const email = "erhaborosagie@gmail.com";
    
console.log( `Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task.${email}`);