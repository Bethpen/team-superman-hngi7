<?php

  /*
    *Just trying to keep things simple    *
    *but still avoid being accused of     *
    *plagiarism because this task doesn't *
    *have many unique solutions           *
  */

  $output = 'Hello World, this is Emmanuel Menyaga with HNGi7 ID HNG-02898 using PHP for stage 2 task.sparklinsparky@gmail.com';

  echo $output;