let name = "Hamzat Ridwan Babatunde";
let id = "HNG-00707";
let language = "JavaScript";
let email="ridwanulllah@gmail.com";


function hng(name, id, language, email){

  console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`);
}
hng(name, id, language, email);