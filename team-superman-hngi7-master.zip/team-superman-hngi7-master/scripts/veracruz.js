var intro="Hello World, this is ";
var myName="GBOLAHAN VERACRUZ";
var hngId="HNG-03044";
var lang="javascript";
var email="veracruzfrancis@gmail.com";
var challenge=(intro+""+myName+ " with HNGi7 ID "+hngId+" using "+lang+" for stage 2 task"+"."+email);
console.log(challenge);
