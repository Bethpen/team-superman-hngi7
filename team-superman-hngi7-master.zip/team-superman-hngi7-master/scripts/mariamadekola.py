# CODE TO OUT PUT SOME TEXT

fullname = "Mariam Adekola"
id = "HNG-01221"
language = "Python"
email = "mariam.adekola10@gmail.com"

def introGreeting():
    return ("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}".format(fullname, id, language,email))

print(introGreeting())