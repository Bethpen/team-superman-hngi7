<?php
$email ="adepojuadeyemi11@gmail.com";

if(isset($email)){
    echo 'Hello World, this is Adepoju Adeyemi with HNGi7 ID HNG-01540 using PHP for stage 2 task.'.$email;
}
?>