name = "Emmanuel Dickson"
hng_id = "HNG-05835"
programming_language = "Python"
email = "emmanueldickson5@gmail.com"

print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}"
.format(name, hng_id, programming_language, email))

