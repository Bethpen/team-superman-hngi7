<?php
echo 'Hello World, this is Arturo Delgado with HNGi7 ID HNG-00083 using PHP for stage 2 task.ajdelgados@gmail.com';
