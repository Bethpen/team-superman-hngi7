const data = [
    "Aiyegbusi omotola",
    "HNG-00564",
    "Javascript",
    "Youngtola@gmail.com",
]
const description = (name, ID, Language, Email) => {
    console.log(`Hello World, this is ${name} with HNGi7 ID ${ID} using ${Language} for stage 2 task.${Email}`)
};
description(data[0], data[1], data[2], data[3]); 