name= "Gbolahan Veracruz"
ID= "HNG-03044"
lang= "python"
mail= "veracruzfrancis@gmail.com"
scr=("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}").format(name,ID,lang,mail)
print(scr)
