let fullname = 'Okiemute Gold';
let hngid = 'HNG-01033';
let language = 'Javascript';
let email = 'goldokiemute@gmail.com';

function goldTask2(fullname, hngid, language, email) {
    console.log(`Hello World, this is ${fullname} with HNGi7 ID ${hngid} using ${language} for stage 2 task.${email}`);
}
goldTask2('Okiemute Gold', 'HNG-01033', 'Javascript', 'goldokiemute@gmail.com')
