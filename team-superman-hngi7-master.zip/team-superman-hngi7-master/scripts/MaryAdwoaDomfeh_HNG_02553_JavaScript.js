

const name = 'Mary Adwoa Domfeh';
const id = 'HNG-02553';
const language = 'JavaScript';
const email ='domfehadwoamary@gmail.com';

console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`);


