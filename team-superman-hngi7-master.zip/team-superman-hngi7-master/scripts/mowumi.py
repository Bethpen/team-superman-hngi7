def introduction(name, ID, language, mail):
    print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}".format(name, ID, language, mail))


introduction("Boluwatife Oduyemi", "HNG-00152", "Python", "archerleo1@gmail.com")
