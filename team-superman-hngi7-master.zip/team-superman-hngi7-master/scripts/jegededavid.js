
function hngdavid() {

    let name = `Jegede David `;
    let id = `HNG-05938`;
    let lang = `JavaScript`;
    let email = `davidstick766@gmail.com`;

    let message = `Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task.${email}`;
    console.log(message);
}

hngdavid();
