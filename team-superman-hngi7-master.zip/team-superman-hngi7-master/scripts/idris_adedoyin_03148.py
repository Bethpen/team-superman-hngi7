print("Hello World, this is Idris Adedoyin with HNGi7 ID HNG-03148 using Python for stage 2 task.dreezybines@gmail.com")
