<?php
$full_name = "Emmanuel Akachukwu";
$id = "HNG-00326";
$language = "PHP";
$email = "emmanuelakachukwu1@gmail.com";

$result = "Hello World, this is ${full_name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}";

echo $result;