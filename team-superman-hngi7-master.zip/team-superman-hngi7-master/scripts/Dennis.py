
def task(name, hnd_id, email, lang):
    print("Hello World, this is " + name + " with HNGi7 ID " + hnd_id + " using " + lang + " for stage 2 task.{}".format(email))


if __name__ == "__main__":
    task(name="Dennis Chukwunta", hnd_id="HNG-01734",email="chuksmcdennis@yahoo.com", lang="Python")
    