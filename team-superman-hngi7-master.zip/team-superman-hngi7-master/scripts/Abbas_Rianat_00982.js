function riri(fullname="Abbas Rianat", id ="HNG-00982", email ="rihanatoluwatosin@gmail.com", language ="JavaScript"){
    console.log(
     `Hello World, this is ${fullname} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`
    );
}
riri();