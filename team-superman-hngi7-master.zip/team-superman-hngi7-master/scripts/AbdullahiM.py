message = "Hello World, This is Abdullahi Mustapha Muhammad with HNGi7 ID HNG-01823 using python for stage 2 task. musteey.abt@gmail.com"
print(message)
