let full_name = "Emmanuel Blessing AJIBOLA";
let id = "HNG-06562";
let email = "aemmanuelblessing@gmail.com";
let lang = "JavaScript";

function displaymsg() {
let msg = "Hello World, this is " + full_name + " with HNGi7 ID " + id + "using " + lang + "for stage 2 task. " + email;
console.log(msg);
}

displaymsg();
