const fullName = 'Familoyo Temidayo';
const id = 'HNG-06454';
const language = 'JavaScript';
const email = 'famtemsam1@gmail.com';

const introduceSelf = (fullName, id, language, email) => {
	console.log(
		`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`
	);
};

introduceSelf(fullName, id, language, email);