const introduceYou = (fullName, id, language, email) => {
	console.log(
		`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`
	);
};

const fullName = 'Oluwakayode Fadoju';
const id = 'HNG-01390';
const language = 'JavaScript';
const email = 'fadojuk@gmail.com';

introduceYou(fullName, id, language, email);
