( (name, id, language, email) =>
    console.log(`Hello world, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`)
)('Aniediabasi Etukudo', 'HNG-04075', 'Javascript', 'aniediabasi.etukudo@gmail.com');