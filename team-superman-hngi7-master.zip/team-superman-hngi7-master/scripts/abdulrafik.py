def hng_stage2_task(name, id, lang, email):
    print(f" Hello World, this is {name} with HNGi7 ID:  {id} using {lang} for stage 2 task.{email}")


hng_stage2_task("Abdul Rafik Al-hassan", "HNG-05318", "Python","aral-hassan001@st.ug.edu.gh")