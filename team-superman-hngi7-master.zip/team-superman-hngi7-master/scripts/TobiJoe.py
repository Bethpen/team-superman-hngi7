print("Hello World, this is Joseph Oluwatobi \
with HNGi7 ID HNG-02926 using python for stage 2 task.joe.oluwatobi@gmail.com")
