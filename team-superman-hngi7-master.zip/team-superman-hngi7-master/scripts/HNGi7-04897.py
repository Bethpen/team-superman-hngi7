print ("Hello World, this is Awojide Margaret with HNGi7 ID HNG-04897 using python for stage 2 task.awojidemargaret99@gmail.com")
