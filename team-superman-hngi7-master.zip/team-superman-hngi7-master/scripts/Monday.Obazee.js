function hngTask(name, hngId, language, email) {
  console.log(
    `Hello World, this is ${name} with HNGi7 ID ${hngId} using ${language} for stage 2 task.${email}`
  );
}
hngTask("Monday Obazee", "HNG-01812", "Javascript", "Mondayobazee@gmail.com");
