<?php
echo "Hello World, this is Qozeem Odeniran with HNGi7 ID 01681 using PHP for stage 2 task.muhdqozeem@gmail.com";
?>