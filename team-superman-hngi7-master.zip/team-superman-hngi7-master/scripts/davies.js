const helloHng=(hngName, hngId, language, email)=>{
    console.log(`Hello World, this is ${hngName} with HNGi7 ID ${hngId} using ${language} for stage 2 task.${email}`);
}
helloHng("Fatimah Davies", "HNG-04778", "Javascript", "daviesfatimah97@gmail.com");
