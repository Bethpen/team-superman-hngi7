


print("Hello World, this is Judicaelle Ben MBOUNGOU with HNGi7 ID HNG-00304 using python for stage 2 task. benjudicaelle@gmail.com")
