const fullName = "Mugisha Charbel Michael"
const id = "HNG-01930"
const language = "JavaScript"
const email = "micmug235@gmail.com"

const output = `Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`

console.log(output)