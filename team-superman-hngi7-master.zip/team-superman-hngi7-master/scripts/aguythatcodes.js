let fullname = "Emmanuel Amodu";
let id = "HNG-05308";
let language = "Javascript";
console.log(`Hello World, this is ${fullname} with HNGi7 ID ${id} using ${language} for stage 2 task.amodue15@gmail.com`);