def ini():
    gre = "Hello World, this is "
    #id1 = " Inioluwa Olaniran with" 
    #lang = HNGi7 ID HNG-04487 using python for stage 2 task.
    #email = "ifiy.olaniran@gmail.com"
    print(gre + "Inioluwa Olaniran with" + " HNGi7 ID HNG-04487" +
          " using python for stage 2 task."+"ifiy.olaniran@gmail.com")
ini()
