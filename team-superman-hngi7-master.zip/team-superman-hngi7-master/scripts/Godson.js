
const myPerson = {
    firstName:"Adeshina",
    lastName:"Ogunyomi",
    track:"frontend",
    HNGi7_ID: "02569",
    programming: "Javascript",
    myIntroduction: function () {
        console.log ( "Hello World, My name is " + this.lastName + " " + this.firstName + " with HNGi7 INTERNSHIP ID " + this.HNGi7_ID + " using " + this.programming + " for stage 2 task ");
    }
    
};
myPerson.myIntroduction();


