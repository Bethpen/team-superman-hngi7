let myIntro = (fullName, ID, language, Email) =>
		 {
    console.log(`Hello World, this is ${fullName} with HNGi7 ID ${ID} using ${language} for stage 2 task.${Email}`)
     
}


        myIntro("Balogun Dolapo", "HNG-04619", "JavaScript","lanrechuks@yahoo.com")
