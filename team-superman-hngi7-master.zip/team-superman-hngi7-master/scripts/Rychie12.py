Name = 'Richmond Ayitey'
Hng_id = 'HNG-00234'
Language = 'Python'
Email = 'richmondayitey12@gmail.com'
print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}".format(Name, Hng_id, Language, Email))
