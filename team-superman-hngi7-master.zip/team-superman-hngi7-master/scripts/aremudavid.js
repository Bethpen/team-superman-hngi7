var myDetails = {
    name: 'Aremu David',
    HNGi7ID: 'HNG-00640',
    language: 'Javascript',
    email: 'dheyved1@gmail.com'
};
console.log("Hello World, this is" + " " + myDetails.name + " " + "with HNGi7 ID" + " "  + myDetails.HNGi7ID + " " + "using" + " " + myDetails.language + " " + "for stage 2 task." + myDetails.email);