
function myHNG(fullname, id, language, email) 
{
  console.log(
    `Hello World, this is ${fullname} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`);
}
myHNG("Adibe Bamidele", "HNG-04857", "Javascript", "bamz4all@gmail.com");
