 var output;
       var myInfo = {
           fullName: "Kenechukwu Nwobodo",
           id: "HNG-03863",
           email: "nwobodokenechukwu2@gmail.com",
           language: "Javascript"
       }
       output = "Hello World, this is " + myInfo.fullName + " with HNGi7 ID "
       + myInfo.id + " using " + myInfo.language + " for stage 2 task." + myInfo.email;

       console.log(output);