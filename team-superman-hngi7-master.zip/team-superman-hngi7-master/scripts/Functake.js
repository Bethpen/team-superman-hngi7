let info = [
    fullName : 'Ajayi Michael',
    let id : 'HNG-00384',
    let language : 'JavaScript',
    let email : 'ajayimichael150@gmail.com'
]
    let profile = 'Hello World, this is ${info.fullName} with HNGi7 ID ${info.id} using ${info.language} for stage 2 task. ${info.email}';
    
    console.log(profile);
