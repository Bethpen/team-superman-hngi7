Name = "Odinakachi Nnuforole"
ID = "HNG-00938"
Language = "Python"
Email = "nnuforole.odinaka@gmail.com"

def greeting():
    print("Hello World, this is" , Name
           +" with HNGi7" + " ID", ID
          +" using" , Language + " for stage 2 task."
          +Email)

greeting()
