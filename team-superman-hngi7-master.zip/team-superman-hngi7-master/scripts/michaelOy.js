
let name = "Michael John";
let id = "HNG-00424";
let lang = "JavaScript";
let email = "johnmikeloy@gmail.com";

function myInfo(){
    console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task.${email}`);
}

myInfo();