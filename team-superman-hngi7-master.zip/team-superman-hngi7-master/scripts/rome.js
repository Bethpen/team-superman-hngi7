
const task = ( fullName = "Nnodum Kenechukwu Joseph", id = "HNG-05791", language = "JavaScript", email = "k3ncey@gmail.com") => {
	 console.log (`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`);
};
task();

