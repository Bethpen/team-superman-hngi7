<?php

// Variables
$fullName = "Ebuka Abraham";
$id = "HNG-01238";

// EMAIL
$email = "buka4rill@gmail.com";

$language = "PHP";

$output = "Hello World, this is $fullName with HNGi7 ID $id using $language for stage 2 task.$email";



// Output 
echo $output;
