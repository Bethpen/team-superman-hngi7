
const Name = "OGUNEKUN SEGUN VICOR";

const id = "HNG-03092";

const email = "ogunekun@gmail.com";

const language = "javascript";

const text = () => {
    return "Hello world. This is ${name} with HNGI7 ID ${id} using ${language} for stage 2 task.${email}"};
console.log(text());
