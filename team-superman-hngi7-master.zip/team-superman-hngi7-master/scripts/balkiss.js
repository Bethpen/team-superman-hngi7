let intern = {
    name: "Ogundotun Balkiss",
    id: "HNG-00945",
    language: "Javascript",
    Email: "ogundotunbalkiss@gmail.com"
};
console.log(`Hello World, this is ${intern.name} with HNGi7 ID ${intern.id} using ${intern.language} for stage 2 task.${intern.Email}`);