def my_function(name, id, language, email):
    print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}".format(name, id, language, email))
my_function("Abakar Issa","HNG-04278","Python","amahamatissa1@gmail.com")