def show(fname, idHNG, progLang, email):
    print(f'Hello World, this is {fname} with HNGi7 ID {idHNG} using {progLang} for stage 2 task.{email}')

show("Oyakhilome Jesuseme","HNG-02397", "python", "oyakhilomejesuseme@gmail.com")