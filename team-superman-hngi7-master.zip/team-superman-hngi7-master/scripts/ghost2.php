<?php
$name="Homasom Amadi";
$email="homasom.amadi@yahoo.com";
$id="HNG-01806";
$lang="PHP";
 echo "Hello World, this is $name with HNGi7 ID $id using $lang for stage 2 task .$email";
     
?>