<?php
	echo "Hello World, this is Saka Sheriff Alade with HNGi7 ID HNG-02701 using PHP for stage 2 task.adetunji_alade2005@yahoo.com";
?>
