<?php
echo 'Hello World, this is Adetunji Oluwaferanmi with HNGi7 ID HNG-00748 using PHP for stage 2 task.oluwaferanmiadetunji@gmail.com';
