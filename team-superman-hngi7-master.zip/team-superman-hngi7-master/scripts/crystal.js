let name = "Opeyemi Owolabi";
let id = "HNG-03599";
var email = "Johnowolabi41@yahoo.com"
let language = "Javascript";

let ouput = "Hello World, this is " + name +  " with HNGi7 ID " + id + " using " + language + " for stage 2 task." + email;


console.log(ouput);

