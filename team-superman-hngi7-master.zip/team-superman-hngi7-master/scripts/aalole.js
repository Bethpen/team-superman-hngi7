
const aaloleHngDetails = (name, id, lang, email) =>
  `Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task.${email}`;

aaloleHngDetails("Rasheed Mikail Abiodun", "HNG-02286", "JavaScript", "Rasheedabiodun556@yahoo.com");
console.log(aaloleHngDetails("Rasheed Mikail Abiodun", "HNG-02286", "JavaScript", "Rasheedabiodun556@yahoo.com"));
