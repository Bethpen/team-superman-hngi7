def secondTask(name, ID, language, email):
    print("Hello World, this is {} with HNGi7 ID {} using {} for Stage 2 Task.{}".format(name, ID, language, email, ))

secondTask("Tikare Oluwatomiloba", "HNG-02041","Python", "tikaretomiloba@gmail.com")


