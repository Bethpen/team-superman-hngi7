var name = "Abdullah Oladeji";
var id = "HNG-02718";
var lang = "JavaScript";
var email = "oladejiabdullah17@gmail.com"

function mytask(name,id,lang,email){
    console.log("Hello World, this is " + name + " with HNGi7 ID " + id + " using " + lang + " for stage 2 task." + email);
}
mytask(name,id,lang,email);