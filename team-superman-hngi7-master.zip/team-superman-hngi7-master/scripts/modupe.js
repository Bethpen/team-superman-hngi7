// HNG Task two
function tasktwo(name,hngid,language,email){
    console.log("Hello world, this is" + " " + name + " " + "with HNGi7 ID " + " " + hngid + " " + "using " + " " + language + " " + "for stage 2 task."+ email)

}
tasktwo("Ige Modupe", "HNG-0410", "JavaScript", "igeoluwamodupe1@gmail.com");
