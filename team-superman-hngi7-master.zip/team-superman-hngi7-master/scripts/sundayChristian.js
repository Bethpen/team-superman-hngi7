  
    var fullName ="Christian Sunday";
    var hngId  = "HNG-03696";
    var languageUsed = "JavaScript";
    var email = "chris4christ25@yahoo.com";
    
    function outcome(a, b, c, d){
        console.log(`Hello World, this is ${a} with HNGi7 ID ${b} using ${c} for stage 2 task. ${d}`)
    }
    
    outcome(fullName, hngId, languageUsed, email)