<?php
$output = 'Hello World, this is Nnamani Solomon with HNGi7 ID HNG-05483 using PHP for stage 2 task';
echo $output;

?>
