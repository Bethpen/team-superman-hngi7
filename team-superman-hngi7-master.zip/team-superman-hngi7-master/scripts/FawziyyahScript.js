const taskFunc = () => {
    const name = "Fawziyyah Agboola"
    const id = "HNG-00081"
    const email = "fawzibiyemi@gmail.com"
    const stack = "Javascript"
    const response = `Hello World, this is ${name} with HNGi7 ID ${id} using ${stack} for stage 2 task.${email}`
    console.log(response)
}

taskFunc()

