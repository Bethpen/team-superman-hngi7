const internName = "Christian Ndu";
const hngId = "01290";
const preferredLang = "Javascript";
const myEmail = "christiannduh@gmail.com";

function namecheck(){
    console.log(`Hello World, this is ${internName} with HNGi7 ID HNG-${0}${Number(hngId)} using ${preferredLang} for stage 2 task.${myEmail}`)
}
//Number
namecheck()


