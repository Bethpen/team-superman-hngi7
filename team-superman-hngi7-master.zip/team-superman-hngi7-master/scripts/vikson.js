const identification = (fullName, id, language, Email) => {
const intro =`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${Email}`
console.log(intro)
}
identification('Victor Steven Nnaji', 'HNG-03108', 'JavaScript', 'steven.vikson@gmail.com')
