<?php
$full_name = "Sunday Amuke";
$id = "HNG-02082";
$lang = "PHP";
$email = "sundayamuke7@gmail.com";

echo "Hello World, this is $full_name with HNGi7 ID $id using $lang for stage 2 task.$email";
?>
