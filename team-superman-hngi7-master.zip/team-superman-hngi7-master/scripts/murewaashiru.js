const introduction = (name, id, language, email) => {
  console.log(
    `Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`
  );
};

introduction(
  'Omomurewa George-Ashiru',
  'HNG-00015',
  'Javascript',
  'rachelleashiru@gmail.com'
);
