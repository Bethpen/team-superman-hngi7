<?php
//defining variables
$fullname = "IDOWU OLAYINKA AYOBAMI";
$ID  = "HNG-02697";
$language = "PHP";
$email = "olayinkancs@gmail.com";

//printing out 

echo "Hello World, this is $fullname with HNGi7 ID $ID using $language for stage 2 task.$email";
