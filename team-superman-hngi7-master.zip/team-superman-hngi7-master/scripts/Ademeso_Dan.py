
# Script created by Daniel ADEMESO for HNGi7 Intern 

def input(name, HNGID, Language, Email):
    return ("Hello World, this is " + (name) +" with HNGi7 ID " +(HNGID)+ " using "+ (Language) + " for stage 2 task."+(Email))


print(input("Daniel Ademeso", "HNG-03169", "python", "danielademeso1@gmail.com"))




