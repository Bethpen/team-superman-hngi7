let name = "Ajayi John";
let id = "HNG-00374";
let language = "Javascript";
let email="ajayitaiwojohnmatt@gmail.com";


function taskHng(name, id, language, email){

  console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`);
}
taskHng(name, id, language, email);
