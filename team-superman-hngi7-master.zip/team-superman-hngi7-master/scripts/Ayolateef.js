
const task = [
	"Abdullateef Ayodele Salaudeen",
	"HNG-02762",
	"Javascript",
	"latmania@gmail.com"
];
const lateef =(name,id,lang,email) => {
console.log(`Hello World, this is ${name} with HNGi7 ID ${id} 
using ${lang} for stage 2 task .${email}`)
};
lateef(task[0],task[1],task[2],task[3]);
