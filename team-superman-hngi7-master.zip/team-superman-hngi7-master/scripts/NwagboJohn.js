const details = (fullname, id, language) => {
    const email = "nwagbojohn@gmail.com";
    return `Hello World, this is ${fullname} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`
}
console.log(details("Nwagbo John", "HNG-01765", "Javascript"))
