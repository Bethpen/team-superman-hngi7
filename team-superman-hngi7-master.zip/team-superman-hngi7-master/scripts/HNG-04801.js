console.log (
    "Hello world, this is Osunlana Jesutofunmi with HNGi7 ID 04801 using Javascript for stage 2 task.jesutofunmiosunlana@gmail.com"
)