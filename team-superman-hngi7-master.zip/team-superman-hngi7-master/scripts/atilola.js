function davidAtilola(){

    const fullName = 'David Atilola';
    const id = 'HNG-01583'
    const language = 'JavaScript';
    const email = 'atiloladavid1@gmail.com'

    console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`)

}
davidAtilola()