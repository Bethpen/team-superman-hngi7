<?php

echo "Hello World, this is Olayiwola Odunsi with HNGi7 ID HNG-05291 using PHP for stage 2 task.olayiwolaodunsi@gmail.com";
