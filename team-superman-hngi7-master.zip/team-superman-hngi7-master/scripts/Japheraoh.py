Print ("Hello World, this is Olaku Japheth with HNGi7 ID HNG-05733 using Python for stage 2 task.olakujapheth@gmail.com")
