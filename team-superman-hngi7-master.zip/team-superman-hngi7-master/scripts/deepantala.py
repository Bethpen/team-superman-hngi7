def stage1_intro(ID, name, lang, email):
    print("Hello World, this is {0} with HNGi7 ID {1} using {2} for stage 2 task.{3}".format(name, ID, lang, email))


stage1_intro("HNG-00064", "Deep Antala", "Python", "deep.antala@yahoo.com")