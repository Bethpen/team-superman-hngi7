//Some es6 syntax here, should be supported
let name = "Ochonogor Eze";
let id = "HNG-00949";
let language = "JavaScript";
let email="sendezeamail@gmail.com";
console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`);
