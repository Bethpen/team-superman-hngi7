let Name = "Oyoh Edmond",
    Id = "HNG-01275",
    Lang = "Javascript",
    Email = "Chiwunmba@gmail.com";

console.log(`Hello world,this is ${Name} with HNGi7 ${Id} using ${Lang} for stage 2 task. ${Email}`);

