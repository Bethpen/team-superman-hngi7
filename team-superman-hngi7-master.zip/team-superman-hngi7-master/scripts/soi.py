"""This script was created by Success Ikhinobele"""

data = {"firstName" : "Success",
        "lastName": "Ikhinobele",
        "language" : "python",
        "id" : "HNG-00099",
       "email" : "ikhinobelesuccess@gmail.com"}



script = print("Hello World, this is {} {} with HNGi7 ID {} using {} for stage 2 task.{}".format(data['firstName'], data['lastName'],data['id'], data['language'], data['email']))


def output():
    return script

output()
