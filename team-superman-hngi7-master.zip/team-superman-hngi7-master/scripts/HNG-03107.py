print("Hello World, this is Chukwuemeka Samuel Egwuonwu with HNGi7 ID HNG-03107 using Python for stage 2 task.chukwuemeka.samuel29@gmail.com")
