/** @format */

const myDetails = [
	(FULLNAME = 'Oluwatomi Oyinkansolami Atansuyi'),
	(ID = 'HNG-01218'),
	(LANGUAGE = 'Javascript'),
	(EMAIL = 'tomisinatansuyi@gmail.com'),
];

const feedback = `Hello World, this is ${FULLNAME} with HNGi7 ID ${ID} using ${LANGUAGE} for stage 2 task.${EMAIL}`;

console.log(feedback);
