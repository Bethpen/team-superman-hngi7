print("Hello world, this is kayode oshodi with ID HNG-01936 using python for stage 2 task.kayodeoshodi400@gmail.com")

