//stage2

   const introduction = (name, id, language, email) => {
  console.log(
    `Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`
  );
};
introduction(
  'Fele Omolola','HNG-01729','JavaScript','feleolaife@gmail.com');
