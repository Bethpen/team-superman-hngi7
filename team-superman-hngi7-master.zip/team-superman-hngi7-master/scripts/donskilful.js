/* Hng task
A function that returns my name, hng id, my programming language & my email address */

function Welcome(myName, myHngId, myProgrammingLanguage, myEmail) {

    console.log(`Hello World, This is ${myName} with HNGi7 ID ${myHngId} using ${myProgrammingLanguage} for the stage 2 task .${myEmail}`);
}

Welcome("Onoriode Ufuomabede Peace", "HNG-05747", "Javascript", "donskilful@gmail.com");