#this program will take input and format it
print ("Hello world,this is %s with %s  using %s for stage task 2.%s " %("oluwapelumi oni","HNG-04612","Python","onioluwapelumi2014@gmail.com"))

