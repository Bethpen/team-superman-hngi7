<?php
$name = "David Roderick Dowuona";

$hng_id = "HNG-01136";

$language = "PHP";

$email = "daviddowuona9.dd@gmail.com";


echo "Hello World, this is {$name} with HNGi7 ID {$hng_id} using {$language} for stage 2 task.{$email}";
