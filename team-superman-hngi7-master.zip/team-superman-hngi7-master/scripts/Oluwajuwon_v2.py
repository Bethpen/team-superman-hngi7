print("Hello World, this is Oluwajuwon ODUNITAN with HNGi7 ID HNG-05726 using Python for stage 2 task.oduns07@gmail.com")
