print("Hello World, this is Precious Richard with HNGi7 ID HNG-02932 using Python for stage 2 task.onengiye.richard@gmail.com")
