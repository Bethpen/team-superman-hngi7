name = 'Nkwachi Nwamaghinna'
hngID = 'HNG-02656'

print('Hello World, this is '+name+' with HNGi7 ID '+hngID+' using python for stage 2 task.nkwachinwamaghinna@gmail.com')
