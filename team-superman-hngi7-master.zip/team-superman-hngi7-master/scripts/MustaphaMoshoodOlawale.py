def task_2 (name, id, language, email):
	print("Hello World, this is {0} with HNGi7 ID {1} using {2} for stage 2 task. {3}".format(name, id, language, email))

task_2("Mustapha Moshood Olawale", "HNG-05611", "Python", "folarinolawale3415@gmail.com" )




