
# A function to accept 3 string arguments and return an expected string 
# containing the HNGi7 Intern profile

def greet_hello(full_name, id, language,email):
    return ("Hello World, this is {0} with HNGi7 ID {1} using {2} for stage 2 task {3}".format(full_name,id,language,email))


print(greet_hello("Oshoke Louis", "HNG-01673","python", "goldbars.ng@gmail.com"))

