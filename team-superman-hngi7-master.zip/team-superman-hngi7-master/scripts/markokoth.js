const markIntroduction = (fullName, id, language, email) => {
    console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`)
}

markIntroduction('Mark Okoth', 'HNG-01803', 'JavaScript', 'markokoth96@gmail.com')