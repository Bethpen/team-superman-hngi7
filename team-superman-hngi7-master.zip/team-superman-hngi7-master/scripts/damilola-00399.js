function myDetails(fullname, id, language, email) {
  console.log(
    `Hello World, this is ${fullname} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`
  );
}
myDetails("Damilola Owolabi", "HNG-00399", "JavaScript", "owolabidamilola98@gmail.com");


