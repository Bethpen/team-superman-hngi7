let fullName= "Doyinsola Egbewande";
let iD= "HNG-01670";
let languageUsed= "JavaScript";
let email="egbewandefolahanmi@gmail.com";
console.log("Hello World, this is " +  fullName + "" + " with HNGi7 ID " + "" + iD + " " + " using " + "" +  languageUsed + " for stage 2 task. "  + email);
