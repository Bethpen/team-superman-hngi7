
var fullName = "Godspower Agofure";
var idNo = "HNG-06251";
var language = "JavaScript";
var email = "godspower.agofure@gmail.com";
function hngIntern(name, id, lang, mail) {
  console.log(
    "Hello World, this is " + name + " with HNGi7 ID " + id + " using " + lang + " for stage 2 task." + mail
  );
}
hngIntern(fullName, idNo, language, email);

