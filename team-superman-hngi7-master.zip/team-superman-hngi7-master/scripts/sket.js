function firstTask(FullName, HNGId, Language, Email)
 {
    console.log(
      `Hello World, This is ${FullName} with HNGi7 ID ${HNGId} using ${Language} for stage 2 task.${Email}`
    );
  }
  firstTask("Shobande James", "HNG-01145", "Javascript", "shobandejames@gmail.com");
  