//this is task two
//function to run the code
let myName="Fajuyagbe Ezekiel";
let identification="HNG-01359";
let scripting_language="Javascript";
let email="fajuyagbeezekiel90@gmail.com";
function hNGi7TeamTaskSuperman(name, id, lang, mail) {
//output data
  console.log(
    "Hello World, this is " + name + " with HNGi7 ID " + id + " using " + lang + " for stage 2 task."+ mail
  );
}
hNGi7TeamTaskSuperman(myName, identification, scripting_language,email);



