function introduce(name="Ali Abdul Ganiy", ID="HNG-01101",lang="javascript", email="alialaba079@gmail.com"){
console.log(`Hello World, this is ${name} with HNGi7 ID ${ID} using ${lang} for stage 2 task.${email}`)
}
introduce()
