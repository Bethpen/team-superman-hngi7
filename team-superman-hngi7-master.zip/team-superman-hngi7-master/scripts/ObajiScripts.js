function stage1(fullName, hId, language, email) {
    console.log(`Hello World, this is ${fullName} with HNGi7 ID ${hId} using ${language} for stage 2 task.${email}`);
  }
  stage1("Obaji Chukwuemeka", "HNG-00990", "Javascript", "realbaji16@gmail.com");
  
