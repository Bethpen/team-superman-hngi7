const name = 'Yusuf Abdulgafar';
const id = 'HNG-01368';
const language = 'javascript';
const email = 'gaftofi@gmail.com';

const introduce = (name, id, language, email) => {
  
 console.log(`Hello world, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`);

};

introduce (name, id, language, email);

