
var fullName = 'Bakare Samuel', ID = 'HNG-02316', language = 'javascript';
var Email = 'bakareayomiku@gmail.com';

console.log('Hello World, this is '+fullName+' with HNGi7 ID '+ID+' using '+language+' for stage 2 task.'+Email);