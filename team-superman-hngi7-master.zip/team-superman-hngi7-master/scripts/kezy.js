let myFullName = 'Okoro Kingsley';
let myIdNo = 'HNG-01757';
let myLanguage = 'Javascript';
let myEmail = 'kezykeen@gmail.com';

function HNG7(myFullName, myIdNo, myLanguage, myEmail) {
    console.log(
        "Hello World, this is " + myFullName + " with HNGi7 ID " + myIdNo + " using " + myLanguage + " for stage 2 task."+ myEmail
    )
}
HNG7(myFullName, myIdNo, myLanguage, myEmail);