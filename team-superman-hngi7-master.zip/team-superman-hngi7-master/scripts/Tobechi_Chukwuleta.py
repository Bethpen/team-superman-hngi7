# -*- coding: utf-8 -*-
"""
Created on Wed Jun  3 01:48:52 2020

@author: Tobechi Chukwuleta
"""

import sys
def my_script():
    print('Hello World, this is %s with HNGi7 ID %s using %s for stage 2 task.%s' % ('Chukwuleta Tobechi', 'HNG-03085', 'Python', 'tobechichukwuleta125@gmail.com'))
    
my_script()
sys.stdout.flush()