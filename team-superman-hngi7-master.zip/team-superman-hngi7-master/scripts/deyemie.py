fullname = 'Atoyegbe Adeyemi'
hngid = 'HNG-04780'
email = 'herdeyemie@gmail.com'
language = 'Python' 

print("Hello World, this is", fullname, "with HNGi7 ID", hngid, "using", language, "for stage 2 task.{}".format(email))
