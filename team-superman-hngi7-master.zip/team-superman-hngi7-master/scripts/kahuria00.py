name='Charity Wanjiru'
ID='00621'
language='Python'
email='charitykahuria@gmail.com'


print("Hello World, this is {0}  with HNGi7 ID {1} using {2} for stage 2 task.{3}".format(name,ID,language,email))



