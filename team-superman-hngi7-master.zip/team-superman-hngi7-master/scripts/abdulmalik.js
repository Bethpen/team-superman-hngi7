const name = "Abdulmalik Ayorinde"
const id = "HNG-06387"
const lang = "JavaScript"
const mail = "malik.ayo4life@gmail.com"


const details = () => {
    console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task.${mail}`)
 }

 
 details()

