/*function self_Id(name, id, language){
    var email = "segunvictor55@yahoo.com"
    console.log("Hello World, this is " + name + " with HNGi7 ID " + id + " using " + language + " for stage 2 task.email")
};

self_Id( "Adetunji Segun", "HNG-05531", "JavaScript" );
*/








function self_Id(name, id, language, email){

    console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`)
};

self_Id( "Adetunji Segun", "HNG-05531", "JavaScript", "segunvictor55@yahoo.com" );