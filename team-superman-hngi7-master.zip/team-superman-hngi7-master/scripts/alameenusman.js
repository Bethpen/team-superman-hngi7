function ameen(name, id, email, language) {
    console.log(
        `Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`
    );
}

ameen("Alameen Usman", "HNG-04325", "lekanusman07@gmail.com", "JavaScript");