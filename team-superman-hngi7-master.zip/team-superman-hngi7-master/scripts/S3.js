let name = 'Oluseyi Imanah';
let  id = 'HNG-03003';
let language = 'javascript';
let email = 'seyicole01@gmail.com';

const myScript = () => {
   let  info =`Hello world, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`;
 console.log(info);
     
 }
 myScript()