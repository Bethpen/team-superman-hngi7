<?php
echo "Hello World, this is Evans Roy with HGi7 ID HNG-04524 using PHP for stage 2 task.evansroysir@gmail.com";
?>
