function myScript(fullname,ID,language,email){
    console.log(
        `Hello World, my name is ${fullname} with HNGi7 ID ${ID} using ${language} for stage 2.${email}`
    );
}
myScript("Millicent Wanjiru Kiruri", "03381", "JavaScript", "theemisskiruri@gmail.com");