
const id = 'HNG-04231';
const name = 'Ajakaye Ayobami';
const progLang = 'Javascript';
const email = 'ajakayetolu@gmail.com';

console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${progLang} for stage 2 task.${email}`);

