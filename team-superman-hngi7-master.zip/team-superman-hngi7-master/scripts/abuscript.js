

function internship (fullname, id, lang,email) {
  console.log(
    `Hello World, this is ${fullname} with HNGi7 ID ${id} using ${lang} for stage 2 task.${email}`
  );
 }
 internship ("Abu Sulaiman", "HNG-02738","javascript","aburex6@gmail.com")
