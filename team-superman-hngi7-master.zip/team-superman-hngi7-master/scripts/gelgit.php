<?php
$fname = "Micheal Daralola Oketunde";
$ID = "HNG-04388";
$lang = "PHP";
$email = "michaeldaralola123@gmail.com"


echo 'Hello World, this is $fname with HNGi7 ID $ID using $lang for stage 2 task.$email';

?>
