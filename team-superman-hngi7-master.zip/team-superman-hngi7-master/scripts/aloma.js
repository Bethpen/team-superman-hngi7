/* Hng task 1  introduction */

function introduction(myName, myHngId, myProgrammingLanguage, myEmail) {

    console.log(`Hello World, this is ${myName} with HNGi7 ID ${myHngId} using ${myProgrammingLanguage} for the stage 2 task.${myEmail}`);
}

introduction("Adeyemi idris oladayo", "HNG-03260", "Javascript", "drizlad@gmail.com");