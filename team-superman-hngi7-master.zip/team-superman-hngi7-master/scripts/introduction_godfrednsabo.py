def Helloworld(Full_Name, HNGi7_ID, language):
    print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.".format(Full_Name, HNGi7_ID, language))

Helloworld("Godfred Nsabo", "HNG-05292", "Python")