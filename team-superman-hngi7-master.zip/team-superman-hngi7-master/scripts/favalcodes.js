const fullName = "Favour Ezinne Arua";
const id = "HNG-04184";
let lang = "Javascript";
let email = "favourvalg@gmail.com";

console.log(
    "Hello World, this is " + fullName + " with HNGi7 ID " + id + " using "+ lang +" for stage 2 task." + email
  );
