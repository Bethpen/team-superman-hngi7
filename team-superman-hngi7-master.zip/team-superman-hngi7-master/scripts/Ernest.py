Name_user = "Owojori Ernest Tolulope"
hng_id_user = "HNG-01824"
email = "owojori.tolulope@gmail.com"
language = "Python"

def task(Name, hng_id, language, email):
    output = "Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}".format(Name, hng_id,language, email)
    return output


print(task(Name = Name_user, hng_id = hng_id_user, language=language, email = email))


    