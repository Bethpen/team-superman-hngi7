const fullName = 'Olusola Adeyeye';
const id = 'HNG-04898';
const language = 'JavaScript';
const email = 'checksola@gmail.com';

const introduceSelf = (fullName, id, language, email) => {
	console.log(
		`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`
	);
};

introduceSelf(fullName, id, language, email);