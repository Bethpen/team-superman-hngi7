const salamu ="Hello World, this is Varis Gikonyo Mwaniki with HNGi7 ID HNG-03436 using JavaScript for stage 2 task.levanvaris@gmail.com";
console.log(salamu);