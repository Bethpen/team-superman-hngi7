
<?php 
$FullName = "Blessing Roland";
$HNGi7id = "HNG-02628";
$Lang = "PHP";
$Email = "Rolyconsult@gmail.com";


echo "Hello World, this is ".$FullName." with HNGi7 ID ".$HNGi7id." using ".$Lang." for stage 2 task. " .$Email;
?>