const name = "Prince Chimaobi";
const id = "HNG-00996";
const language = "JavaScript";
const email = "royadeveloper01@gmail.com";

const myInfo = (name, id, language,email) => {
    console.log(`Hello World, This is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`);
}
myInfo(name,id,language,email);
