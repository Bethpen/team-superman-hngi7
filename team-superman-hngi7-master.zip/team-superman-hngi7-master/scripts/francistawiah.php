<?php

	
	echo "Hello World, this is Francis Tawiah with HNGi7 ID HNG-01722 using Php for stage 2 task.tawiahfrancis13@gmail.com";
	
?>
