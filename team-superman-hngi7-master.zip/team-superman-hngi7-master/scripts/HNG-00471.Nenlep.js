function task(){
  var fname = "Nenlep Ishaku";
  var hng_ID = "HNG-00471";
  var email = "nenlep12345@gmail.com";
  var lang = "JavaScript";
  console.log(`Hello World, this is ${fname} with HNGi7 ID ${hng_ID} using ${lang} for stage 2 task.${email}`);
}
task();