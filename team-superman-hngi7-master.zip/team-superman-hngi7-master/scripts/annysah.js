const name = 'Anisat Akinbani'
const id = 'HNG-01710'
const language = 'javascript'
const email = 'anisatakinbani13@gmail.com'

function myDetails(name, id, language, email) {
    console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`)
}
myDetails('Anisat Akinbani', 'HNG-01710', 'javascript', 'anisatakinbani13@gmail.com')
