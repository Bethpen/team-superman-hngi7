function introduceSelf(){
  let fullName = "Ifeoma Oluwapelumi Jonah";
  let id = "HNG-04143";
  let email = "ifyajoke@gmail.com";
  let language = "JavaScript";

  console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.${email}`)
  
  }
  introduceSelf();